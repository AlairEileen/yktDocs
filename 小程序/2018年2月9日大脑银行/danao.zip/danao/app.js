//app.js
var common = require('/utils/common.js');
App({
  
  onLaunch: function () {
    
  },

  /**
   * 获取用户信息
   */
  getUserInfo: function (cb) {

    var that = this

    if (this.globalData.userInfo) {

      typeof cb == "function" && cb(this.globalData.userInfo)

    } else {

      //调用登录接口
      wx.login({
        success: function (res) {

          var code = res.code

          wx.getUserInfo({
            success: function (res2) {
              that.globalData.userInfo = res2.userInfo

              // 数据准备 
              // var data = { rawData: res2.rawData, signature: res2.signature, code: code }
              var data = { encryptedData: res2.encryptedData, iv: res2.iv, code: code }

              // 调用ajax
              common.postAjax('login', data)
                .then(res => {

                  console.log('登录获取用户信息', res)

                  wx.setStorageSync('unionId', res.data.data.unionId)
                  typeof cb == "function" && cb(that.globalData.userInfo)

                })

            },
            fail: function (res2) {

              wx.redirectTo({ url: '/pages/authorization/authorization' })

            }
          })

        }
      })

    }

  },

  globalData: {

    url: 'https://test.yoao.com/wxMini/apps/',
    userInfo: null

  }

})