// 引入底层javascriptPromise并声明模块
import Promise from './es6-promise.min';

/*************************************************华丽的分割线************************************************/
/**
 * GET   请求函数
 * url   传递方法名
 * data  传递数据对象
 */
const getAjax = (url, data) => {
  
  // 其他接口
  var app = getApp()
  var version = '1.0'
  var unionId = wx.getStorageSync('unionId')

  // 判断data是否有其他参数
  if (data == undefined) {
    
    // 没有
    var data = { unionId: unionId, version: version }

  } else {

    // 有
    var d = { unionId: unionId, version: version }
    var data = mergeObj(d, data)
  
  }

  return new Promise((resolve, defaults) => {
    wx.request({
      url: app.globalData.url + url,
      data: data,
      method: 'GET',
      header: { 'content-type': 'application/json' },
      success: resolve,
      fail: function (res) {
        console.log('失败返回数据', res)
      },
      complete: function () {

      },
    })
  });
}

/*************************************************华丽的分割线************************************************/
/**
 * POST  请求函数
 * url   传递方法名
 * data  传递数据对象
 */
const postAjax = (url, data) => {

  // 其他接口
  var app = getApp()
  var version = '1.0'
  var unionId = wx.getStorageSync('unionId')

  // 判断data是否有其他参数
  if (data == undefined) {

    // 没有
    var data = { unionId: unionId, version: version }

  } else {

    // 有
    var d = { unionId: unionId, version: version }
    var data = mergeObj(d, data)

  }

  return new Promise((resolve, defaults) => {
    wx.request({
      url: app.globalData.url + url,
      data: data,
      method: 'POST',
      header: { 'content-type': 'application/x-www-form-urlencoded' },
      success: resolve,
      fail: function (res) {
        console.log('失败返回数据', res)
      },
      complete: function () {

      },
    })
  });

}

/*************************************************华丽的分割线************************************************/
/**
 * object 对象合并
 * o1     对象一
 * o2     对象二
 */
function mergeObj(o1, o2) {
  for (var key in o2) {
    o1[key] = o2[key]
  }
  return o1;
}

/*************************************************华丽的分割线************************************************/
/**
 * 弹出显示1
 */
function showToast(title){
  wx.showToast({
    title: title,
    icon: 'loading',
    duration: 2000,
    mask: true
  })
}

/*************************************************华丽的分割线************************************************/
/**
 * 弹出显示2
 */
function showModal(t, c, s){
  wx.showModal({
    title: t,
    content: c,
    showCancel: s,
    confirmColor: '#27B361',
  })
}

/*************************************************华丽的分割线************************************************/
/**
 * 删除数组中指定下标返回新数组
 * @param arr 数组
 * @param index 数组下标(int)
 */
function resetArray(arr, index){
  var newArr = []
  var k = 0
  for (var i=0,l=arr.length; i < l; i++) {
    if (i != index) {
      newArr[k] = arr[i] 
      k++
    }
  }
  return newArr;
}

/*************************************************华丽的分割线************************************************/
/**
 * 判断数组是否存在某个元素
 * @param arr 数组
 * @param index 字符串
 */
function contains(arr, str) {
  var i = arr.length;
  while (i--) {
    if (arr[i] === str) {
      return true;
    }
  }
  return false;
}

/*************************************************华丽的分割线************************************************/
/**
 * 删除数组中指定的下标返回新数组
 * @param arr 数组
 * @param k 下标
 */
function recombination(arr, k) {
  // 声明空数组
  var res = []
  var j = 0
  // 循环传进来的数组
  for (var i = 0, alength = arr.length; i < alength; i++) {
    if (i != k) {
      res[j] = arr[i]
      j++
    }
  }
  return res
}

// 引入函数
module.exports = {
  getAjax: getAjax,
  postAjax: postAjax,
  contains: contains,
  showToast: showToast,
  showModal: showModal,
  resetArray: resetArray,
  recombination: recombination,
}
