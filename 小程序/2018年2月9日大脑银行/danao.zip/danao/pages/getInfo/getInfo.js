// pages/getInfo/getInfo.js
var common = require('../../utils/common.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isShow: false,    // 是否显示全部通知
    items:[
      {
        name: '',     // 默认初始化姓名
        cardType: '身份证', // 默认证件类型
        cardCode: '', // 默认证件号码
        country: '',  // 默认国家地区
        phone: '',    // 默认手机号
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 显示隐藏通知
   */
  showView: function () {
    
    if (this.data.isShow) {
      
      this.setData({ isShow: false })
    
    } else {
      
      this.setData({ isShow: true })
    
    }
  
  },

  /**
   * 添加报名人员
   */
  getAdd: function (e) {

    var data = {
      name: '',     // 默认初始化姓名
      cardType: '身份证', // 默认证件类型
      cardCode: '', // 默认证件号码
      country: '',  // 默认国家地区
      phone: '',    // 默认手机号
    }

    var items = this.data.items
    items.push(data)

    this.setData({ items: items })    

  },

  /**
   * 删除报名人员 
   */
  getDelete: function (e) {

    var index = e.currentTarget.dataset.index
    var items = this.data.items
    items = common.resetArray(items, index)
    this.setData({ items: items })

  },

  /**
   * 获取报名姓名,身份证,手机号
   */
  getValue: function (e) {

    var index = e.currentTarget.dataset.index
    var ct = e.currentTarget.dataset.ct
    var items = this.data.items
    
    switch (Number(ct)) {
      
      // 修改用户姓名
      case 1:
        items[index].name = e.detail.value
        break;
      
      // 修改用户身份证号码
      case 2:
        items[index].cardCode = e.detail.value
        break;

      // 修改用户手机号
      case 3:
        items[index].phone = e.detail.value
        break;
    }

    this.setData({ items: items })

  },

  /**
   * 获取报名证件类别,国家
   */
  getChoose: function (e) {

    

  },


  /**
   * 表单提交
   */
  getFrom: function () {

    var that = this

    var data = {}

    console.log(data)

    return

    common.postAjax('', data)
      .then(res => {

        console.log('表单提交', res)

      })


  }
  
})