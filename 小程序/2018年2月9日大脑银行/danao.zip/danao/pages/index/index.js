//index.js
//获取应用实例
var common = require('../../utils/common.js');
const app = getApp()
Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    show: 2, // 显示页面 (1所有课程,2近期课程)
    current: 1,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this

    wx.getUserInfo({
      success: res => {

        that.setData({ userInfo: res.userInfo })
      
      }
    })
    
    app.getUserInfo(userInfo => {
      
      console.log('获取用户', userInfo)

      // 查询九大课程信息和课程广告
      common.postAjax('course/index')
        .then(res => {

          console.log('查询九大课程信息和课程广告', res)

          for (var i = 0, l = res.data.data.adLessonList.length; i < l; i++) {
            res.data.data.adLessonList[i].adCode = res.data.data.adLessonList[i].adCode.replace(/\\/ig, '\/')
          }

          that.setData({ 
            adLessonList: res.data.data.adLessonList, 
            lessList: res.data.data.lessonProductList, 
          })

        })

      // 查看近期课程
      common.postAjax('course/recent')
        .then(res => {

          console.log('查看近期课程', res)
          if (res.data.code == 0) {

            that.setData({ lessonList: res.data.data.lessonList })

          }

        })
    
    })

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 切换页面
   */
  handPage: function (e) {
    
    this.setData({ show: Number(e.detail.current)+1 })
  
  },

  /**
   * 切换页面
   */
  getHand: function (e) {

    this.setData({ current: Number(e.currentTarget.dataset.show)-1 })

  },

  /**
   * 跳完详情
   */
  getCode: function (e) {

    wx.navigateTo({ url: '../detail/detail?code=' + e.currentTarget.dataset.code })

  },

  /**
   * 判断
   */
  getjudge: function () {

    var that = this

    common.postAjax('mini/userinfo/get')
      .then(res => {

        console.log(res)
        if (res.data.code == 0) {
          
          if (res.data.data.idCard == '') {

            // 没有绑定
            wx.navigateTo({ url: '../signup/signup' })

          } else {

            // 绑定信息
            wx.navigateTo({ url: '../getInfo/getInfo' })

          }

        }

      })

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {


    
  }

})
