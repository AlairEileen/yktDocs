// pages/detail/detail.js
var common = require('../../utils/common.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    click: 1,
    pageCount: 5,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this

    wx.getUserInfo({
      success: res => {

        that.setData({ userInfo: res.userInfo })

      }
    })

    // common.postAjax('', )
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 
   */
  getTitle: function (e) {

    this.setData({ click: Number(e.currentTarget.dataset.ct) })

  },

  /**
   * 客户见证
   */
  custome: function () {

    var that = this
    var data = {
      pageSize: that.data.page,
      pageCount: 5,
    }

    common.postAjax('course/queryCustomerWitnessList', data) 

  }

})