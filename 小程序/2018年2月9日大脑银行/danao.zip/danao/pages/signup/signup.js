// pages/signup/signup.js
var common = require('../../utils/common.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index1: 0,
    index2: 0,
    name: '张波', // 姓名
    IdCard: '152725199509281812', // 证件号码
    mobile: '15947658171', // 手机号
    areaCode: ['中国(+86)', '美国(+1)'], // 国家区号
    idCardType: ['身份证', '护照'], // 证件类型
    smsCode: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    
  
  },

  /**
   * 获取值
   */
  getValue: function (e) {

    switch (e.currentTarget.dataset.ct) {

      // 姓名
      case '1':
        this.setData({ name: e.detail.value })
        break;
      
      // 证件号
      case '2':
        this.setData({ IdCard: e.detail.value })
        break;
      
      // 手机号
      case '3':
        this.setData({ mobile: e.detail.value })
        break;
      
      // 验证码
      case '4':
        this.setData({ smsCode: e.detail.value })
        break;

    }

  },

  /**
   * 选择
   */
  getChoose: function (e) {

    if (e.currentTarget.dataset.ct == 1) {
      
      this.setData({ index1: e.detail.value })
    
    } else {
      
      this.setData({ index2: e.detail.value })
    
    }

  },

  /**
   * 获取验证码
   */
  getCode: function () {

    var that = this
    if (that.data.mobile.length != 11) {
      common.showModal('提示', '手机号输入错误', false)
      return
    }

    var data = {
      type: 3,
      mobile: that.data.mobile,
      areaCode: (that.data.index2 == 0) ? '86' : '1',
    }

    common.postAjax('mini/verification', data)
      .then(res => {

        console.log(res)
        if (res.data.code == 0) {

          // 成功
          common.showModal('提示', res.data.msg, false)

        } else {

          common.showModal('提示', res.data.msg, false)

        }

      })

  },

  /**
   * 表单提交
   */
  getFrom: function () {

    var that = this
    var data = {
      name: that.data.name,
      IdCard: that.data.IdCard,
      mobile: that.data.mobile,
      areaCode: (that.data.index2 == 0) ? '86' : '1',
      idCardType: Number(that.data.index1)+1,
      smsCode: that.data.smsCode,
    }

    common.postAjax('mini/usercode/bingding', data)
      .then(res => {

        console.log('表单提交行为', res)
        if (res.data.code == 0) {

          wx.redirectTo({ url: '../getInfo/getInfo' })

        } else {
          
          common.showModal('提示', res.data.msg, false)
        
        }

      })

  }


})