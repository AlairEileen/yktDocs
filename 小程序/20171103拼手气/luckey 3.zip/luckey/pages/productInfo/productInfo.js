// pages/productInfo/productInfo.js
var baseUrl = getApp().globalData.baseUrl;
var accountID = wx.getStorageSync("accountId");
Page({
  /**
   * 页面的初始数据
   */
  data: {
    reday_to_buy: true,
    baseimg: baseUrl + "File/FileDownload?fileUrl=",
    jackPotID: '',
    goodsID: '',
    productList: [],
    GoodsInfo: {},
    goodsCoclor: [],
    goodsRule: [],
    color: '',
    rule: '',
    goodsId: '',
    accountID
  },
  getProductDetail: function () {
    var that = this;
    var goodsID = this.data.goodsID;
    console.log(goodsID)
    var date = {};
    var goodsCoclor = [];
    var goodsRule = [];
    date.goodsID = this.data.goodsID
    var url = baseUrl + "Goods/GetGoodsDetail"
    wx.request({
      url: url,
      data: date,
      success: function (e) {
        console.log(e.data.JsonData.GoodsInfo.JackGoods);
        goodsCoclor = e.data.JsonData.GoodsInfo.JackGoods.GoodsColor;
        goodsRule = e.data.JsonData.GoodsInfo.JackGoods.GoodsRule;
        that.setData({
          GoodsInfo: e.data.JsonData.GoodsInfo.JackGoods,
          goodsCoclor: e.data.JsonData.GoodsInfo.JackGoods.GoodsColor,
          goodsRule: e.data.JsonData.GoodsInfo.JackGoods.GoodsRule,
          goodsId: e.data.JsonData.GoodsInfo.JackGoods.GoodsID
        })
      }
    })
  },
  // 点击开团  选择参数
  buy_know: function () {
    console.log("ssss"),
      this.setData({
        reday_to_buy: false,
      })
  },
  //去付款 
  pay_know: function () {
    var that = this;
    this.create_team(that.data.jackPotID);
  },
  create_team: function (jackPotID) {
    var that = this;
    var mainPic = that.data.GoodsInfo.GoodsMainImages[0].FileUrlData[0];
    var url = '/pages/orderInfo/orderInfo?goodsId=' + that.data.goodsId + "&goodsColor=" + that.data.color + "&goodsRule=" + that.data.rule + "&goodsTitle=" + that.data.GoodsInfo.GoodsTitle + "&goodsPic=" + mainPic + "&price=" + that.data.GoodsInfo.GoodsPrice + "&payType=" + that.data.GoodsInfo.GoodsPayType;
    if (jackPotID != null) {
      url = url + "&jackPotID=" + jackPotID
    }
    console.log(url)
    wx.navigateTo({
      url: url,
    })
  },
  choose_color: function (e) {
    console.log(e.detail.value)
    var color = e.detail.value;
    this.setData({
      color: color
    })

  },
  choose_rule: function (e) {
    console.log(e.detail.value)
    var rule = e.detail.value
    this.setData({
      rule: rule
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // wx.startPullDownRefresh()
    this.setData({
      goodsID: options.product_id,
      jackPotID: options.jackPotID
    })
    this.getProductDetail();
    wx.setNavigationBarTitle({
      title: '商品详情',
    })
  },
  go_back: function () {
    wx.navigateBack({})
  },

  cancal_buy: function () {
    this.setData({
      reday_to_buy: true,

    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log("down")
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log("bottom")
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})