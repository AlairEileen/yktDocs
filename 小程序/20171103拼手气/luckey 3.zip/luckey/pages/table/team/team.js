// pages/table/team/team.js
var page = 0;
// todo   type  1 
var date_type = 1;
var baseUrl = getApp().globalData.baseUrl;
var hasPocket = wx.getStorageSync("hasPocket")
// 请求数据
var loadMore = function (that) {
  that.setData({
    hidden: false
  });

  var url = baseUrl + "Goods/GetGoodsList";
  wx.request({
    url: url,
    data: {
      pageIndex: page,
      goodsPayType: date_type,
    },
    success: function (res) {
      //console.info(that.data.list);
      console.log(res.data.JsonData)
      if (res.data.StatusCode == 1000) {
        var list = [];
        if (that.data.list != null) {
          list = that.data.list;
        }
        for (let i = 0; i < res.data.JsonData.length; i++) {
          list.push(res.data.JsonData[i]);
        }
        console.log(list)
        that.setData({
          jsonData: list
        });
        page++;
        that.setData({
          hidden: true
        });
      } else if (res.data.StatusCode == 3000) {
        wx.showToast({
          title: '没有更多',
        })
        that.setData({
          hidden: true
        });
      }
    }
  });
}
Page({
  /**
   * 页面的初始数据
   */
  data: {
    // TODO : 2017年11月21日 红包注释掉了
    hiddenmodal: !hasPocket,
    scroll_top: 0,
    goTop_show: false,
    hidden: true,
    scrollTop: 0,
    scrollHeight: 0,
    jsonData: [],
    baseUrl: baseUrl,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    loadMore(this);
  },
  scrollTopFun: function (e) {
    this.setData({
      scroll_top: e.detail.scrollTop
    });
    if (e.detail.scrollTop > 200) {//触发gotop的显示条件  
      this.setData({
        'scrollTop.goTop_show': true
      });
    } else {
      this.setData({
        'scrollTop.goTop_show': false
      });
    }
  },
  goTopFun: function (e) {
    var _top = this.data.scroll_top;//发现设置scroll-top值不能和上一次的值一样，否则无效，所以这里加了个判断  
    if (_top == 1) {
      _top = 0;
    } else {
      _top = 1;
    }
    this.setData({
      'scrollTop.scroll_top': _top
    });
  },
  topLoad: function (event) {
    //   该方法绑定了页面滑动到顶部的事件，然后做上拉刷新
    page = 0;
    this.setData({
      list: [],
      scroll_top: 0
    });
    loadMore(this);
    console.log("refresh");

  },
  // 元素点击事件
  itemClick: function (e) {
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/productInfo/productInfo?product_id=' + id,
    })
  },
  cancal_pocket: function () {
    this.setData({
      hiddenmodal: true
    })
  },
  open_pocket: function (e) {
    console.log(e)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  bindDownLoad: function () {
    var that = this;
    loadMore(that);
    console.log("lower");
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})