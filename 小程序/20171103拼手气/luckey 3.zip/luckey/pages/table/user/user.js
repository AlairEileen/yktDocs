// pages/table/user/user.js
var baseUrl = getApp().globalData.baseUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    baseUrl: baseUrl,
    hiddenmodal: true,
    userInfo: {},
    unread_count: 3,
    phone: "",
    region: ['广东省', '广州市', '海珠区'],
    customItem: '全部',
    addressInfo: "",
    orderLocationPersonName: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getUserInfo();
    var that = this;
  },
  getUserInfo: function () {
    var that = this;
    var url = baseUrl + "account/GetAccountInfo"
    var id = wx.getStorageSync("accountId")
    wx.request({
      url: url,
      data: {
        accountID: id
      },
      success: function (res) {
        console.log(res.data.JsonData)
        var addressInfo = res.data.JsonData.OrderLocation.AddressDetail;
        var region = res.data.JsonData.OrderLocation.ProvinceCityArea;
        var phone = res.data.JsonData.OrderLocation.OrderLocationPhone;
        var orderLocationPersonName = res.data.JsonData.OrderLocation.OrderLocationPersonName
        that.setData({
          userInfo: res.data.JsonData,
          addressInfo: addressInfo,
          region: region,
          phone: phone,
          orderLocationPersonName: orderLocationPersonName
        })
      }
    })
  },
  call_service: function () {
    var phone = this.data.userInfo.ServicePhone
    wx.makePhoneCall({
      phoneNumber: phone,
    })
  },
  /** 点击收货地址 */
  edit_address: function () {
    this.setData({
      hiddenmodal: !this.data.hiddenmodal
    })
  },
  // picker回调
  locChange: function (e) {
    console.log(e.detail.value)
    this.setData({
      region: e.detail.value
    })
  },
  editAddressInfo: function (e) {
    this.setData({
      addressInfo: e.detail.value
    })
  },
  editReciver: function (e) {
    this.setData({
      orderLocationPersonName: e.detail.value
    })
  },
  editPhoneCall: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },
  //取消按钮  
  cancel: function () {
    this.setData({
      hiddenmodal: true
    });
  },
  //确认  
  confirm: function () {
    var that = this;
    var url = baseUrl + "account/SetAddress"
    wx.request({
      url: url,
      data: {
        accountID: wx.getStorageSync("accountId"),
        provinceArray: that.data.region,
        addressDetail: that.data.addressInfo,
        orderLocationPhone: that.data.phone,
        orderLocationPersonName: that.data.orderLocationPersonName
      }
    })
    this.setData({
      hiddenmodal: true
    })
  },
  wating_join: function () {
    wx.navigateTo({
      url: '/pages/table/user/product_deatil/product_deatil?viewType=0',
    })
  },
  wating_send: function () {
    wx.navigateTo({
      url: '/pages/table/user/product_deatil/product_deatil?viewType=1',
    })
  },
  wating_assess: function () {
    wx.navigateTo({
      url: '/pages/table/user/product_deatil/product_deatil?viewType=2',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})