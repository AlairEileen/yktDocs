// pages/table/user/product_deatil/product_deatil.js
var baseUrl = getApp().globalData.baseUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    jsonData: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    /**
     * type 0 带拼团
     * type 1 待发货
     * type 2 待评价
     */
    var that = this;
    let viewType = options.viewType
    var url = baseUrl;
    var requesData = {}
    var accountID = wx.getStorage({
      key: 'accountId',
      success: function (res) {
        if (viewType == 0) {
          url = url + "JackPot/GetWaitingJoinJackPotList";
          requesData.accountID = res.data;
          requesData.pageIndex = 0
        } else if (viewType == 1) {
          url = url + "JackPot/GetWaitingOrderList";
          requesData.accountID = res.data;
          requesData.orderStatus = 0;
          requesData.pageIndex = 0
        } else if (viewType == 2) {
          url = url + "JackPot/GetWaitingOrderList";
          requesData.accountID = res.data;
          requesData.orderStatus = 1;
          requesData.pageIndex = 0
        }
        wx.request({
          url: url,
          data: requesData,
          success: function (res) {
            console.log(res.data)
            that.setData({
              jsonData: res.data.JsonData,
            })
          }
        })
      },
    })


  },
  btn_click: function () {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '我发起了拼团fallow me!!!',
      path: '/pages/productInfo/productInfo?product_id=5a029caa6b185c2dcc61d8ab',
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})