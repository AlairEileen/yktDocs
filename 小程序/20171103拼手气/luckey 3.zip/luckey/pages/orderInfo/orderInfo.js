// pages/orderInfo/orderInfo.js
var accountId = wx.getStorageSync("accountId");
var baseUrl = getApp().globalData.baseUrl;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    baseimg: baseUrl + "File/FileDownload?fileUrl=",
    userInfo: {},
    addressInfo: '',
    phone: '',
    orderLocationPersonName: '',
    region: [],
    goodsColor: '',
    goodsRule: '',
    goodsId: '',
    goodsTitle: '',
    pic: '',
    price: '',
    payType: '',
    humanList: [3, 4, 5, 6],
    index: 0,
    password: '',
    jackPotID: '',
    canChoose: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var goodsColor = options.goodsColor;
    var goodsRule = options.goodsRule;
    var goodsId = options.goodsId;
    var goodsTitle = options.goodsTitle;
    var pic = this.data.baseimg + options.goodsPic;
    var price = options.price
    var payType = options.payType
    var jackPotID = options.jackPotID
    var that = this;
    //  控制参团 不可再选人数]
    var canChoose;
    if (jackPotID == null) {
      canChoose = true;
    } else {
      canChoose = false;
    }
    this.setData({
      goodsColor: goodsColor,
      goodsRule: goodsRule,
      pic: pic,
      goodsTitle: goodsTitle,
      goodsId: goodsId,
      price: price,
      payType: payType,
      jackPotID: jackPotID
    })
    console.log(options);
    this.getUserInfo();
    this.getPrice(0);
  },
  getUserInfo: function () {
    var that = this;
    var url = baseUrl + "account/GetAccountInfo"
    var id = wx.getStorageSync("accountId")
    wx.request({
      url: url,
      data: {
        accountID: id
      },
      success: function (res) {
        console.log(res.data.JsonData)
        var addressInfo = res.data.JsonData.OrderLocation.AddressDetail;
        var region = res.data.JsonData.OrderLocation.ProvinceCityArea;
        var phone = res.data.JsonData.OrderLocation.OrderLocationPhone;
        var orderLocationPersonName = res.data.JsonData.OrderLocation.OrderLocationPersonName;
        that.setData({
          userInfo: res.data.JsonData,
          addressInfo: addressInfo,
          region: region,
          phone: phone,
          orderLocationPersonName: orderLocationPersonName
        })
      }
    })
  },
  sumbit_order: function () {
    var that = this;
    var jackPotID = that.data.jackPotID;
    var url = baseUrl + "JackPot/RequestCreateJackPot"
    let payType = that.data.payType;
    var param = {};
    param.accountID = accountId;
    param.goodsColor = that.data.goodsColor;
    param.goodsRule = that.data.goodsRule;
    if (jackPotID == null) {
      param.goodsID = that.data.goodsId;
      if (payType == 1) {
        // 多人团
        if (that.data.password == null) {
          wx.showToast({
            title: '清输入拼团密码',
          })
          return;
        }
        param.jackPotPassword = that.data.password;
        param.jackPotPeopleNum = that.data.humanList[that.data.index]

      }
      console.log(that.data.goodsColor)
      // 创建者 和 夺宝
    } else {
      param.jackPotID = that.data.jackPotID
      if (payType == 1) {
        // 多人团
        if (that.data.password == null) {
          wx.showToast({
            title: '清输入拼团密码',
          })
          return;
        }
        param.jackPotPassword = that.data.password;
      }

    }
    wx.request({
      url: url,
      data: param,
      success: function (res) {
        console.log(res.data.JsonData)
        var payData = res.data.JsonData.WXPayData;
        var PayWaitingID = res.data.JsonData.PayWaitingID;
        var result = '';
        wx.requestPayment({
          timeStamp: payData.timeStamp,
          nonceStr: payData.nonceStr,
          package: payData.package,
          signType: payData.signType,
          paySign: payData.paySign,
          'success': function (res) {
            console.log(res)
            wx.navigateTo({
              url: '/pages/payResult/payResult?payWaitingID=' + PayWaitingID,
            })
          },
          'fail': function (res) {
            //"requestPayment:fail cancel"
            wx.showToast({
              title: '支付失败',
            })
          }
        })
      }
    })
  },
  select_number: function (e) {
    var that = this;
    console.log(e.detail.value)
    let index = e.detail.value;
    let num = this.data.humanList[index];
    this.getPrice(num)
    that.setData({
      index: index,
    })
  },
  password_confirm: function (e) {
    console.log(e)
    this.setData({
      password: e.detail.value
    })
  },
  getPrice: function (num) {
    var url = baseUrl + "JackPot/GetJackPotPrice"
    wx.request({
      url: url,
      data: {
        goodsID: that.data.goodsId,
        peopleNum: num
      },
      success: function (e) {
        console.log(e)
        that.setData({
          price: e.data.JsonData
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})