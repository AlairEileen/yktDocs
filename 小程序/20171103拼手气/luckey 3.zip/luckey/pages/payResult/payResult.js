// pages/payResult/payResult.js
var WXGrid = require('../view/wxgrid.js')
var wxgrid = new WXGrid;
var baseUrl = getApp().globalData.baseUrl;
var accountID = wx.getStorageSync("accountId");
var classifies = []

Page({
  /**
   * 页面的初始数据
   */
  data: {
    wxgrid,
    btn_font: "点击邀请好友",
    jsonData: {},
    addressInfo: '',
    phone: '',
    orderLocationPersonName: '',
    region: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    // 5a14ee0773a9f40ea0ac2f7c
    var payWaitingId = options.payWaitingID;

    this.getUserInfo();
    this.getOrderInfo(options.payWaitingID);
  },
  getOrderInfo: function (waitingId) {
    var that = this;
    var url = baseUrl + "JackPot/GetShareJackPotID"
    wx.request({
      url: url,
      data: {
        payWaitingID: waitingId
      }, success: function (e) {
        //TODO  2017-11-22 11:53:30  pic  un load 
        console.log(e.data.JsonData);
        classifies = e.data.JsonData.Participator;
        var peopleNum = e.data.JsonData.JackPotPeopleNum;
        wxgrid.init(1, peopleNum);
        if (classifies.length < peopleNum) {
          for (let i = classifies.length; i < peopleNum; i++) {
            var date = {};
            date.AccountAvatar = "/mipmap/circle.png";
          }
        }
        classifies.push(date)
        wxgrid.data.add("classifies", classifies);
        that.setData({
          jsonData: e.data.JsonData,
          wxgrid: wxgrid,
        })

      }
    })
  },

  getUserInfo: function () {
    var that = this;
    var url = baseUrl + "account/GetAccountInfo"
    var id = wx.getStorageSync("accountId")
    wx.request({
      url: url,
      data: {
        accountID: id
      },
      success: function (res) {
        console.log(res.data.JsonData)
        var addressInfo = res.data.JsonData.OrderLocation.AddressDetail;
        var region = res.data.JsonData.OrderLocation.ProvinceCityArea;
        var phone = res.data.JsonData.OrderLocation.OrderLocationPhone;
        var orderLocationPersonName = res.data.JsonData.OrderLocation.OrderLocationPersonName;
        that.setData({
          userInfo: res.data.JsonData,
          addressInfo: addressInfo,
          region: region,
          phone: phone,
          orderLocationPersonName: orderLocationPersonName
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {
    console.log(e)
    var that = this;
    var title = that.data.jsonData.JackGoods.GoodsTitle;
    var path = '/pages/productInfo/productInfo?product_id=' + that.data.jsonData.JackGoods.GoodsId + "&jackPotID=" + that.data.jsonData.JackPotID;
    return {
      title: title,
      desc: '我正在拼手气商城',
      path: path,
      success: function (res) {
        console.log(res)
      },
      fail: function (res) {
        console.log("fail")
      }
    }
  }
})